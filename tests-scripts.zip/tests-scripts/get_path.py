import pathlib

pathlib.Path(__file__).parent.resolve()

